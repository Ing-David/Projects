from owlready2 import *
import numpy as np


root_path = os.path.normpath(os.getcwd() + os.sep + os.pardir) + '/Projet'
os.chdir(root_path)
print(root_path)
my_world = World()
onto_path.append(root_path)
onto = my_world.get_ontology('file:../books.owl').load()


classes = list(())
properties = list(())
annot_properties = list(())

for item in onto.classes():
    classes.append(item)
for item in onto.properties():
    properties.append(item)
for item in onto.annotation_properties():
    annot_properties.append(item)

sync_reasoner(my_world)
graph = my_world.as_rdflib_graph()


# find books that has a limit price as the price provided 
def findBooksByPrice(price):
    r = list(graph.query("""
                SELECT ?book ?price
                WHERE {
                ?book <http://www.mybooks.org/2021#hasPrice>  ?price.
                }"""))
    r = np.asarray(r)
    books_list = list(())

    for item in r:
        if int(float(item[1])) <= int(price):
            books_list.append((item[0].split('#')[1], item[1]))
    
    return books_list


# recommend phones to users based on brand and OS
def recommendPhone(brand, os):
    uri = '<https://www.gsmarena.com/ontologies/mobile.owl#'
    r = list(graph.query("""PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
                            SELECT ?model
                            WHERE {
                            ?model rdfs:subClassOf <https://www.gsmarena.com/ontologies/mobile.owl#SmartPhone>.
                            ?mi a ?model.
                            ?b a """ + uri + brand + """>.
                            ?o a """ + uri + os + """>.
                            ?mi <https://www.gsmarena.com/ontologies/mobile.owl#hasBrand> ?b.
                            ?mi <https://www.gsmarena.com/ontologies/mobile.owl#hasOS> ?o.
                            }"""))
    r = np.asarray(r)
    recommend = []
    for i in r:
        recommend.append(np.char.split(i, sep='#')[0][1])

    recommend = np.asarray(recommend)
    return recommend


# recommend phones based on chipset
def RecommendOnChipset(chipset):
    uri = '<https://www.gsmarena.com/ontologies/mobile.owl#'
    r = list(graph.query("""PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
                            SELECT ?model
                            WHERE {
                            ?model rdfs:subClassOf <https://www.gsmarena.com/ontologies/mobile.owl#SmartPhone>.
                            ?mi a ?model.
                            ?b a """ + uri + chipset + """>.
                            ?mi <https://www.gsmarena.com/ontologies/mobile.owl#hasChipset> ?b.
                            }"""))
    r = np.asarray(r)
    recommend = []
    for i in r:
        recommend.append(np.char.split(i, sep='#')[0][1])
        # print(np.char.split(i, sep = '#'))

    recommend = np.asarray(recommend)
    return recommend


def teenPhone(ageGroup):
    uri = '<https://www.gsmarena.com/ontologies/mobile.owl#'
    r = list(graph.query("""PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
                            SELECT ?brand
                            WHERE {
                            ?user a """ + uri + ageGroup + """>.
                            ?model rdfs:subClassOf <https://www.gsmarena.com/ontologies/mobile.owl#SmartPhone>.
                            ?phone a ?model.
                            ?user <https://www.gsmarena.com/ontologies/mobile.owl#uses> ?phone.
                            ?phone <https://www.gsmarena.com/ontologies/mobile.owl#hasBrand> ?b.
                            ?b a ?brand.
                            }"""))

    r = np.asarray(r)
    # r = r.flatten()
    b = []
    for i in r:
        b.append(np.char.split(i, sep='#')[0][1])
    b = np.asarray(b)
    brands = []
    for i in b:
        if i != 'NamedIndividual':
            brands.append(i)

    unique, pos = np.unique(brands, return_inverse=True)
    counts = np.bincount(pos)
    maxpos = counts.argmax()

    return brands[maxpos]

#findBooksByPrice(15)

