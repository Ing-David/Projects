from flask import Flask, render_template, request, session, abort
from OWL_Ready.owl_manager import *

app = Flask(__name__)

app.secret_key = "AS9UjjJI0J0JS9j"


@app.route('/')
def home():
    return render_template('wim_books.html')


@app.route("/find/<string:name>/")
def hello(name):
    return render_template('found_wim_books.html', name=name)

#find books for the limit input price
@app.route('/find_books', methods=['GET'])
def search():
    try:
        books_price = request.form['price']

        books = findBooksByPrice(books_price)
        return render_template('found_wim_books.html', b_price=books_price, books_list=books)
    except:
        return render_template('wim_books.html')


@app.route('/query1', methods=['GET'])
def search1():
    try:
        brand_name = request.form['brandname']
        os = request.form['os']
        phones = recommendPhone(brand_name, os)
        return render_template('result1.html', phone_list=set(phones))
    except:
        return render_template('input_form1.html')


@app.route('/query2', methods=['GET'])
def search2():
    try:
        user_name = request.form['username']
        chipset = request.form['cs']

        phones = RecommendOnChipset(chipset)
        print(phones)
        return render_template('result2.html', name=user_name, phone_cs_list=set(phones))
    except:
        return render_template('input_form2.html')


@app.route('/query3', methods=['GET'])
def search3():
    try:
        user_name = request.form['username']
        agegroup = request.form['age']
        phones = teenPhone(agegroup)
        print(phones)

        return render_template('result3.html', name=user_name, phone_age_list=phones)
    except:
        return render_template('input_form3.html')


@app.route('/query4', methods=['GET'])
def search4():
    try:
        user_name = request.form['username']
        brand_name = request.form['brandname']
        os = request.form['os']

        return render_template('result4.html', name=user_name)
    except:
        return render_template('input_form4.html')


app.add_url_rule('/find_books', 'search', search, methods=['GET', 'POST'])
app.add_url_rule('/query1', 'search1', search1, methods=['GET', 'POST'])
app.add_url_rule('/query2', 'search2', search2, methods=['GET', 'POST'])
app.add_url_rule('/query3', 'search3', search3, methods=['GET', 'POST'])
app.add_url_rule('/query4', 'search4', search4, methods=['GET', 'POST'])

if __name__ == "__main__":
    app.run(host='localhost', port=8000)
